package com.example.mygps88;

import android.content.Context;
import android.content.DialogInterface; // Importar para usar AlertDialog
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog; // Importar para usar AlertDialog
import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SensorEventListener sensorEventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner laboratorioSpinner = findViewById(R.id.laboratorio_spinner);
        EditText nombreEditText = findViewById(R.id.nombre_editText);
        EditText rutEditText = findViewById(R.id.rut_editText);
        EditText descripcionEditText = findViewById(R.id.descripcion_editText);
        EditText fechaEditText = findViewById(R.id.fecha_editText); // Campo de fecha
        Button grabarButton = findViewById(R.id.grabar_button);

        // Captura la fecha actual
        LocalDateTime currentDate = LocalDateTime.now();
        String formattedDate = currentDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        fechaEditText.setText(formattedDate);  // Muestra la fecha en el campo

        // Listener para el botón "Grabar Incidente"
        grabarButton.setOnClickListener(v -> {
            String nombre = nombreEditText.getText().toString();
            String rut = rutEditText.getText().toString();
            String descripcion = descripcionEditText.getText().toString();
            String laboratorio = laboratorioSpinner.getSelectedItem().toString();

            if (nombre.isEmpty() || rut.isEmpty() || descripcion.isEmpty()) {
                Toast.makeText(MainActivity.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            } else if (!validarRut(rut)) {
                Toast.makeText(MainActivity.this, "RUT inválido", Toast.LENGTH_SHORT).show();
            } else {
                mostrarDialogoConfirmacion(nombre, rut, laboratorio, descripcion, formattedDate);
            }
        });

        // Inicialización del sensor para detección de la orientación del dispositivo
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sensorEventListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];

                // Verificar si el dispositivo está en posición vertical
                if (x > -1.0 && x < 1.0 && y > 8.0 && y < 10.0 && z > -1.0 && z < 1.0) {
                    String nombre = nombreEditText.getText().toString();
                    String rut = rutEditText.getText().toString();
                    String descripcion = descripcionEditText.getText().toString();
                    String laboratorio = laboratorioSpinner.getSelectedItem().toString();

                    if (nombre.isEmpty() || rut.isEmpty() || descripcion.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    } else if (!validarRut(rut)) {
                        Toast.makeText(MainActivity.this, "RUT inválido", Toast.LENGTH_SHORT).show();
                    } else {
                        mostrarDialogoConfirmacion(nombre, rut, laboratorio, descripcion, formattedDate);
                    }
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {
                // No es necesario para este caso
            }
        };

        // Registrar el listener para el sensor
        sensorManager.registerListener(sensorEventListener, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    // Método para mostrar el diálogo de confirmación
    private void mostrarDialogoConfirmacion(String nombre, String rut, String laboratorio, String descripcion, String fecha) {
        new AlertDialog.Builder(this)
                .setTitle("Confirmar grabación")
                .setMessage("¿Estás seguro de que deseas grabar el incidente?")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        grabarIncidente(nombre, rut, laboratorio, descripcion, fecha);
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss(); // Cerrar el diálogo
                    }
                })
                .show();
    }

    // Función para grabar el incidente
    private void grabarIncidente(String nombre, String rut, String laboratorio, String descripcion, String fecha) {
        // Captura la fecha y hora actual
        LocalDateTime currentDateTime = LocalDateTime.now();
        String formattedDateTime = currentDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        // Mostrar mensaje de incidente grabado
        Toast.makeText(this, "Incidente grabado a las: " + formattedDateTime, Toast.LENGTH_SHORT).show();

        // Aquí puedes almacenar los datos o procesarlos como desees
        // Ejemplo: guardar en base de datos
    }

    // Función para validar el RUT
    private boolean validarRut(String rut) {
        // Validación de formato básico de RUT (puedes ampliarlo según el estándar de tu país)
        String regex = "^[0-9]{7,8}-[0-9Kk]{1}$";
        if (!rut.matches(regex)) {
            return false;
        }

        // Algoritmo para verificar el dígito verificador
        String[] rutParts = rut.split("-");
        int rutSinDigito = Integer.parseInt(rutParts[0]);
        String digitoVerificador = rutParts[1].toUpperCase();

        return digitoVerificador.equals(calcularDigitoVerificador(rutSinDigito));
    }

    // Algoritmo para calcular el dígito verificador del RUT
    private String calcularDigitoVerificador(int rut) {
        int suma = 0;
        int multiplicador = 2;
        while (rut != 0) {
            suma += (rut % 10) * multiplicador;
            rut /= 10;
            if (multiplicador == 7) {
                multiplicador = 2;
            } else {
                multiplicador++;
            }
        }
        int digito = 11 - (suma % 11);
        if (digito == 11) {
            return "0";
        } else if (digito == 10) {
            return "K";
        } else {
            return String.valueOf(digito);
        }
    }

    // Liberar el sensor cuando la actividad se destruya
    @Override
    protected void onDestroy() {
        super.onDestroy();
        sensorManager.unregisterListener(sensorEventListener);
    }
}
